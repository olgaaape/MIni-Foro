<?php 

$asunto = $_REQUEST['asunto'];
$comentario = $_REQUEST ['comentario'];


?>

<form name='comentariorelleno' method="POST">
<table>
<tr>
<td>
tema:
</td>
</tr>
<tr>
<td><textarea name="asunto" rows="1" cols="35"><?php echo $asunto;?></textarea></td>
</tr>
<tr>
<td>
Comentarios:
</td>
</tr>
<tr>
<td><textarea name="comentario" rows="5" cols="35" maxlength="300"><?php echo $comentario;?></textarea></td>
</tr>
</table>
<br>
<input type="submit" name="orden" value="Detalles">
<input type="submit" name="orden" value="Nueva opinión">
<input type="submit" name="orden" value="Terminar">
</form>