<?php

$comentario = $_REQUEST ['comentario'];

echo "<b>Detalles:</b><br>";
echo "Longitud: ". strlen($comentario)."<br>";
echo "Nº de palabras: ". str_word_count($comentario)."<br>"; 
echo "Letra + repetida: ".lmasRepe($comentario)."<br>";
echo "Palabra + repetida: ".pmasRepe($comentario);

function lmasRepe($comentario) {
    $max=0;
    $letra=null;
    $repe=null;
    
    for ($i=0;$i< strlen($comentario);$i++){
        $letra=$comentario[$i];
        if ($letra!=" " && substr_count($comentario,$letra)>$max){
            $max= substr_count($comentario,$letra);
            $repe=$letra;
        }
    }
    return $repe;
}
function pmasRepe($comentario) {
    $max=0;
    $letra=null;
    $repe=null;
    $palabra=null;
    for ($i=0;$i< strlen($comentario);$i++){
        $letra=$comentario[$i];
        if ($letra != " " && $letra!=","){
            $palabra = $palabra.$letra;
           
        }else{
            if ( substr_count($comentario,$palabra)>$max){
                $max= substr_count($comentario,$palabra);
                $repe=$palabra;
                
                
            }
            $palabra=null;
        }
        
    }
    return $repe;
}
    

?>
